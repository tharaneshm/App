# Smart Door Locker Android (LAN)

This project wraps the supplied Smart Door Locker dashboard in an Android WebView and adds a native LAN security monitor.

## Included
- Existing `index-2.html` dashboard preserved as `app/src/main/assets/index.html`.
- ESP32 HTTP/LAN communication.
- Native background/screen-off monitoring of `GET /getLogs` every 2 seconds while monitoring is enabled.
- Android security notifications for newly detected failed attempts:
  - Incorrect PIN
  - Face verification failure
  - Unauthorized RFID
  - Other denied/invalid/unknown attempts
- Notification deduplication using the ESP32 log serial number.
- Foreground monitoring service so the WebView does not need to stay open.
- Boot receiver to restore monitoring after reboot when it was previously enabled.
- Android 13+ notification permission request.
- Cleartext HTTP enabled for the ESP32 LAN endpoint.
- WebView mixed-content support because the supplied dashboard uses HTTPS CDN assets while the ESP32 uses HTTP.

## Build
Open this folder in Android Studio and let it sync the Android Gradle plugin/dependencies. Then use:
**Build > Build APK(s)**.

The supplied environment did not contain an Android SDK/Gradle installation, so an APK binary could not be compiled here. The Android Studio project is prepared for compilation.

## Important
The supplied HTML still loads Tailwind, face-api.js, Chart.js, Font Awesome and Google Fonts from their CDN URLs. The ESP32 itself remains LAN-only; the dashboard's CDN dependencies may require internet access unless those assets are later bundled locally.

The background monitor itself uses only the local ESP32 address.
