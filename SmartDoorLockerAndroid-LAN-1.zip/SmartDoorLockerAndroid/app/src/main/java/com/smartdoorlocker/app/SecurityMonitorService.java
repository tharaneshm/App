package com.smartdoorlocker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SecurityMonitorService extends Service {
    public static final String PREFS = "locker_monitor";
    public static final String KEY_HOST = "esp32_host";
    public static final String KEY_MONITORING = "monitoring";
    private static final String KEY_LAST_SNO = "last_notified_sno";
    private static final String CHANNEL_MONITOR = "locker_monitor";
    private static final String CHANNEL_ALERTS = "locker_security_alerts";
    private static final int FOREGROUND_ID = 2001;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running;

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        startForeground(FOREGROUND_ID, buildForegroundNotification("Watching the ESP32 LAN connection"));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!getPrefs().getBoolean(KEY_MONITORING, false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            executor.execute(this::monitorLoop);
        }
        return START_STICKY;
    }

    private void monitorLoop() {
        while (running) {
            String host = getPrefs().getString(KEY_HOST, "").trim();
            if (!host.isEmpty()) {
                try { pollLogs(host); } catch (Exception ignored) { }
            }
            SystemClock.sleep(2000);
        }
    }

    private void pollLogs(String host) throws Exception {
        String urlText = "http://" + host + "/getLogs?t=" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(6000);
        c.setRequestMethod("GET");
        try {
            if (c.getResponseCode() != HttpURLConnection.HTTP_OK) return;
            InputStream in = c.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            br.close();
            processLogs(new JSONArray(body.toString()));
        } finally { c.disconnect(); }
    }

    private void processLogs(JSONArray logs) {
        if (logs.length() == 0) return;
        String last = getPrefs().getString(KEY_LAST_SNO, null);
        long lastNum = parseLong(last, -1);

        if (last == null) {
            JSONObject latest = logs.optJSONObject(logs.length() - 1);
            if (latest != null) getPrefs().edit().putString(KEY_LAST_SNO, latest.optString("sno", "")).apply();
            return;
        }

        long newestSeen = lastNum;
        for (int i = 0; i < logs.length(); i++) {
            JSONObject log = logs.optJSONObject(i);
            if (log == null) continue;
            String sno = log.optString("sno", "");
            long n = parseLong(sno, -1);
            if (n >= 0 && lastNum >= 0) {
                if (n <= lastNum) continue;
                newestSeen = Math.max(newestSeen, n);
            } else if (!sno.equals(last)) {
                // Non-numeric fallback: use a compound signature.
                String signature = signature(log);
                String savedSig = getPrefs().getString(KEY_LAST_SNO, "");
                if (signature.equals(savedSig)) continue;
                newestSeen = -1;
            } else continue;

            String status = log.optString("status", "");
            if (isFailure(status)) sendSecurityAlert(log);
        }

        if (newestSeen >= 0) getPrefs().edit().putString(KEY_LAST_SNO, Long.toString(newestSeen)).apply();
        else {
            JSONObject latest = logs.optJSONObject(logs.length() - 1);
            if (latest != null) getPrefs().edit().putString(KEY_LAST_SNO, signature(latest)).apply();
        }
    }

    private static String signature(JSONObject log) {
        return log.optString("sno", "") + "|" + log.optString("date", "") + "|" + log.optString("time", "") + "|" + log.optString("method", "") + "|" + log.optString("status", "");
    }

    private static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s); } catch (Exception e) { return fallback; }
    }

    private static boolean isFailure(String status) {
        String t = status == null ? "" : status.toUpperCase();
        return t.matches(".*(INCORRECT|WRONG|FAIL|DENIED|REJECT|INVALID|UNKNOWN|LOCKOUT|LOCKED OUT).*");
    }

    private void sendSecurityAlert(JSONObject log) {
        String method = log.optString("method", "Unknown method");
        String status = log.optString("status", "Access denied");
        String lower = method.toLowerCase();
        String title;
        if (lower.contains("pin")) title = "Security Alert — Incorrect PIN attempt";
        else if (lower.contains("face")) title = "Security Alert — Face verification failed";
        else if (lower.contains("rfid")) title = "Security Alert — Unauthorized RFID attempt";
        else title = "Security Alert — Unauthorized access attempt";

        String time = log.optString("date", "") + " " + log.optString("time", "");
        String message = method + " • " + status + (time.trim().isEmpty() ? "" : " • " + time.trim());
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ALERTS)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .build();
        int id = 3000 + Math.abs(signature(log).hashCode() % 100000);
        nm.notify(id, n);
    }

    private Notification buildForegroundNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_MONITOR)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("Smart Door Locker")
                .setContentText(text)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void createChannels() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_MONITOR, "Locker monitoring", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ALERTS, "Security alerts", NotificationManager.IMPORTANCE_HIGH));
    }

    private android.content.SharedPreferences getPrefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    @Override public void onDestroy() {
        running = false;
        executor.shutdownNow();
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
