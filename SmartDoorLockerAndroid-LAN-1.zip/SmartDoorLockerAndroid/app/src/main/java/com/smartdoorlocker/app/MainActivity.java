package com.smartdoorlocker.app;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private static final int NOTIFICATION_REQUEST = 1001;
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidLockerBridge(this), "AndroidLocker");
        webView.loadUrl("file:///android_asset/index.html");

        requestNotificationPermission();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class AndroidLockerBridge {
        private final Context context;
        AndroidLockerBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface public void setEsp32Ip(String host) {
            if (host == null) return;
            host = host.trim().replaceFirst("^https?://", "").replaceAll("/+$", "");
            context.getSharedPreferences(SecurityMonitorService.PREFS, Context.MODE_PRIVATE)
                    .edit().putString(SecurityMonitorService.KEY_HOST, host).apply();
        }

        @JavascriptInterface public void setMonitoring(boolean enabled) {
            context.getSharedPreferences(SecurityMonitorService.PREFS, Context.MODE_PRIVATE)
                    .edit().putBoolean(SecurityMonitorService.KEY_MONITORING, enabled).apply();
            Intent i = new Intent(context, SecurityMonitorService.class);
            if (enabled) {
                ContextCompat.startForegroundService(context, i);
            } else {
                context.stopService(i);
            }
        }
    }
}
