package com.smartdoorlocker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            if (context.getSharedPreferences(SecurityMonitorService.PREFS, Context.MODE_PRIVATE)
                    .getBoolean(SecurityMonitorService.KEY_MONITORING, false)) {
                ContextCompat.startForegroundService(context, new Intent(context, SecurityMonitorService.class));
            }
        }
    }
}
